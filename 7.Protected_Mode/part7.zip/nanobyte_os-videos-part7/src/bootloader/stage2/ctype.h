#pragma once
#include <stdint.h>
#include <stdbool.h>

bool islower(char chr);
char toupper(char chr);
