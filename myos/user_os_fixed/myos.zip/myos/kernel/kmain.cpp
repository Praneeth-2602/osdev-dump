#include "console.hpp"
#include <stdint.h>

// Direct access to video memory for troubleshooting
static volatile uint16_t* const video_memory = reinterpret_cast<uint16_t*>(0xB8000);

// Entry point called from boot.s
extern "C" void kmain() {
    // Write directly to video memory for troubleshooting
    const char* message = "DIRECT WRITE TEST";
    uint16_t attribute = 0x0A; // Green on black
    
    // Write each character directly
    for (int i = 0; message[i] != '\0' && i < 80; i++) {
        // Each cell is 16-bit: [attribute|character]
        video_memory[i] = (attribute << 8) | message[i];
    }
    
    // Use normal console functions on second line
    vga::clear();
    vga::writes("Hello from myos kernel!\n");
    vga::writes("Welcome to myOS - a simple 32-bit OS\n");
    
    // Enter an infinite loop - in a real OS, this would be
    // the place to initialize system services and enter
    // the main scheduler loop
    while (1) {
        // Use halt to save power while idle
        asm volatile("hlt");
    }
}