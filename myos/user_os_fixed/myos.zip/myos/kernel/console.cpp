#include "console.hpp"

namespace {
    // Current cursor position
    int row = 0;
    int col = 0;
    
    // Default text attribute (bright white on blue)
    uint8_t attrib = 0x1F;

    // Handle newline or cursor overflow
    inline void newline() {
        col = 0;
        if (++row >= vga::H) {
            // Scroll up by one line
            for (int r = 1; r < vga::H; ++r) {
                for (int c = 0; c < vga::W; ++c) {
                    vga::buffer[(r - 1) * vga::W + c] = vga::buffer[r * vga::W + c];
                }
            }
            // Clear last line
            for (int c = 0; c < vga::W; ++c) {
                vga::buffer[(vga::H - 1) * vga::W + c] =
                    (static_cast<uint16_t>(attrib) << 8) | static_cast<uint8_t>(' ');
            }
            row = vga::H - 1;
        }
    }
} // anonymous

namespace vga {

void clear() {
    // Fill screen with spaces using the current attribute
    for (int r = 0; r < H; ++r) {
        for (int c = 0; c < W; ++c) {
            buffer[r * W + c] = (static_cast<uint16_t>(attrib) << 8) | static_cast<uint8_t>(' ');
        }
    }
    // Reset cursor position to top-left
    row = col = 0;
}

void putc(char c) {
    // Handle special characters
    if (c == '\n') {
        newline();
        return;
    }
    
    // Debug output - write character to the top corner as well
    if (row == 0 && col == 0) {
        for (int i = 0; i < 16; i++) {
            buffer[i] = (static_cast<uint16_t>(0x4F) << 8) | static_cast<uint8_t>('A' + i); // Red on white
        }
    }
    
    // Write character to screen with current attribute
    uint16_t cell = (static_cast<uint16_t>(attrib) << 8) | static_cast<uint8_t>(c);
    buffer[row * W + col] = cell;
    
    // Advance cursor position
    if (++col >= W) {
        newline();
    }
}

void writes(const char* s) {
    // Safety check for null pointer
    if (!s) return;
    
    // Write each character in the string
    while (*s) {
        putc(*s++);
    }
}

} // namespace vga
