#include "console.hpp"

// Entry point called from boot.s
extern "C" void kmain() {
    vga::clear();
    vga::writes("Hello from myos kernel!\n");
    while (1) {}
}