#include "console.hpp"


namespace {
int row = 0, col = 0;
uint8_t attrib = 0x07; // light grey on black


void newline() {
col = 0;
if (++row >= vga::H) {
// simple scroll
for (int r = 1; r < vga::H; ++r)
for (int c = 0; c < vga::W; ++c)
vga::buffer[(r-1)*vga::W + c] = vga::buffer[r*vga::W + c];
for (int c = 0; c < vga::W; ++c)
vga::buffer[(vga::H-1)*vga::W + c] = (attrib << 8) | ' ';
row = vga::H - 1;
}
}
}


namespace vga {
void clear() {
for (int r = 0; r < H; ++r)
for (int c = 0; c < W; ++c)
buffer[r*W + c] = (attrib << 8) | ' ';
row = col = 0;
}


void putc(char c) {
if (c == '\n') { newline(); return; }
buffer[row*W + col] = (attrib << 8) | static_cast<uint8_t>(c);
if (++col >= W) newline();
}


void writes(const char* s) {
while (*s) putc(*s++);
}
}